// DateTest.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Date.h"
#include <iostream>
#include <conio.h>

using namespace std;


int main()
{
	Date d1(12, 8, 1992);
	Date d2;

	cout << "The first date is " << d1 << endl;
	cout << "The second date is " << d2 << endl;

	_getch();


	cout << "The first date (+= 7) is " << (d1+=7) << endl;

	_getch();


	d2.setDate(2, 28, 2008);
	cout << "The second date is now " << d2 << endl;
	cout << "The second date plus a day (++d2) is " << ++d2 << " (Leap year allowing the 29th)" << endl;

	_getch();


	Date d3(7, 13, 2010);
	cout << "Testing prefix increment operator.." << endl;
	cout << "The third date is " << d3 << endl;
	cout << "The third date plus a day (++d3) is " << ++d3 << endl;
	cout << "The third date is now " << d3 << endl;

	_getch();


	cout << "Testing postfix increment operator.." << endl;
	cout << "The third date is " << d3 << endl;
	cout << "The third date is " << d3++ << " ..plus a day (d3++)." << endl;
	cout << "The third date is now " << d3 << endl;

	_getch();


	cout << "End of line." << endl << "Press any key to exit.";

	_getch();

    return 0;
}

