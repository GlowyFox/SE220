#include "stdafx.h"
#include "Date.h"
#include <iostream>
#include <string>

using namespace std;

// Defining the Days array. As a side note, could easily use slot 0 as a special case for leap years.
const array<unsigned int, 13> Date::days = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

Date::Date(int month, int day, int year)
{
	setDate(month, day, year);
}

void Date::setDate(int mm, int dd, int yy)
{
	if (mm >= 1 && mm <= 12)
	{
		month = mm;
	}
	else
	{
		throw invalid_argument("Month value must be in the range of 1 to 12!");
	}
	if (yy >= 1900 && yy <= 2100) //CAUTION: This program is vurlerable to an eventual Y2.1k bug!
	{
		year = yy;
	}
	else
	{
		throw invalid_argument("Year value must be in the range of 1900 to 2100! Sorry if you're from the future and getting this message.");
	}
	if ((month == 2 && leapYear(year) && dd >= 1 && dd <= 29) || (dd >= 1 && dd <= days[month]))
	{
		day = dd;
	}
	else
	{
		throw invalid_argument("Day is invalid for the given month and year!");
	}
}

bool Date::leapYear( int testYear )
{
	if (testYear % 400 == 0 || (testYear % 100 != 0 && testYear % 4 == 0)) //Man, leap years are kiiinda bullshit. Can't change the Sol3 calenders so easily, though.. Bah.
	{ return true; }
	else //A surpuflouous 'else' here - Look nicer, but could just let the 'if' fail and fall through to this.
	{ return false; }
	
}

bool Date::endOfMonth( int testDay) const
{
	if (month == 2 && leapYear(year))
	{
		return testDay == 29;
	}
	else
	{
		return testDay == days[month];
	}
}

Date::~Date()
{
}


std::ostream & operator<<(std::ostream &outStream, const Date &Date)
{
	static string monthName[13] = { "","January","Febuary", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };
	//Goin' off-script here, what a rebel!
	string numSuffix;
	switch (Date.day % 10) {
	case 1:
		numSuffix = "st";
		break;
	case 2:
		numSuffix = "nd";
		break;
	case 3:
		numSuffix = "rd";
		break;
	default:
		numSuffix = "th";
		break;
	}
	outStream << "the " << Date.day << numSuffix << " of " << monthName[Date.month] << ", " << Date.year;
	return outStream;
}

//Incrementation stuff below!

void Date::helpIncrement()
{
	if (!endOfMonth(day))
	{
		++day;
	}
	else
	{
		if (month < 12)
		{
			++month;
			day = 1;
		}
		else
		{
			month = 1;
			day = 1;
			++year;
		}
	}
}

Date &Date::operator++()
{
	helpIncrement();
	return *this;
}
Date Date::operator++(int)
{
	Date temp = *this;
	helpIncrement();
	return temp;
}
Date &Date::operator+=(unsigned int additionalDays)
{
	for (int i = 0; i < additionalDays; i++)
	{
		helpIncrement();
	}

	return *this;
}