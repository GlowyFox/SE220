// Lab1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <vector>
#include <conio.h>
using namespace std;

#define ARRAY_WIDTH 2
#define ARRAY_DEPTH 2

void courseAverage(int* p, int length)
{
	int avgVal = 0;
	for(int i = 0; i < length; i++)
	{
		avgVal += p[i];
	}
	avgVal = avgVal/length;

	std::cout << "The average of the given array/vector is " << avgVal << "." << endl;
}

int _tmain(int argc, _TCHAR* argv[])
{
	int gradeArray[ARRAY_WIDTH][ARRAY_DEPTH];
	int inputBuffer = 0;
	bool isValidInput = false;

	for(int L1 = 0; L1 < ARRAY_WIDTH; L1++)
	{
		for(int L2 = 0; L2 < ARRAY_DEPTH; L2++)
		{
			while(!isValidInput)
			{
				cout << "Please input a grade value (integer, 1 to 100): ";
				cin >> inputBuffer;
				if(cin.fail()) 
				{
					cout << "Invalid input!" << endl;
					cin.clear();
					cin.sync();
				}
				else if(inputBuffer > 100)
				{
					cout << "Value too high." << endl;
				}
				else if(inputBuffer < 1)
				{
					cout << "Value too low." << endl;
				}
				else
				{
					gradeArray[L1][L2] = inputBuffer;
					isValidInput = true;
				}
			}
			isValidInput = false;
		}
	}

	vector<int> gradeVector;

	//This is a sloppy way of doing it - I found something on StackExchange that looks interesting
	//for doing this sort of thing for multi-dimensional arrays.
	//Namely,  for ( auto x : reinterpret_cast<int ( & )[sizeof( a ) / sizeof( ***a )]>( a ) ) 
	for(auto &a : gradeArray)
	{
		for(int x : a)
		{
			cout << "Pushing value " << x << " into vector from array." << endl;
			gradeVector.push_back(x);
		}
	}

	cout << "The vector has " << gradeVector.size() << " elements in it, expected " 
		 << ARRAY_DEPTH + ARRAY_WIDTH << "."<< endl;
	cout << "Press any key to sort the grades.." << endl;
	_getch();

	int countAGrade = 0, 
		countBGrade = 0, 
		countCGrade = 0, 
		countDGrade = 0, 
		countFGrade = 0;

	for(int givenGrade : gradeVector)
	{
		/*While this works, it still feels wrong to me, especially if you want to bother
		  with subdividing every major level with +/-.
		switch((int)givenGrade/10){
		case 10:
		case 9:
			countAGrade++;
			break;		
		case 8:
			countBGrade++;
			break;
		case 7:
			countCGrade++;
			break;
		case 6:
			countDGrade++;
			break;
		default:
			countFGrade++;
			break;
		}
		*/
		if(givenGrade >= 90) //Knowing that 100 is the upper bound for the grade overall, 
							//and 90 is the lower cutoff for an A.
		{
			countAGrade++;
		}
		else if(givenGrade >= 80) //Lower bound for B.
		{
			countBGrade++;
		}
		else if(givenGrade >= 70) //Lower bound for C.
		{
			countCGrade++;
		}
		else if(givenGrade >= 60) //Lower bound for D.
		{
			countDGrade++;
		}
		else //If all else fails,
		{
			countFGrade++;
		}
		//This way is certianly more accepting to future expansion, in my opinion.
		//..And a bit less likely to cause brain-dead students to go about doing ~40 cases.
	}

	cout << "The grade breakdown is as follows: " << endl
		 << "Number of 'A's: " << countAGrade << endl
		 << "Number of 'B's: " << countBGrade << endl
		 << "Number of 'C's: " << countCGrade << endl
		 << "Number of 'D's: " << countDGrade << endl
		 << "Number of 'F's: " << countFGrade << endl;
	
	cout << "Press any key to average the grades.." << endl;
	_getch();

	courseAverage(gradeVector.data(), gradeVector.size());

	cout << "Press any key to exit." << endl;
	_getch();

	return 0;
}

