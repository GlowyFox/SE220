#include "stdafx.h"
#include "OvernightPackage.h"
#include <iostream>

using namespace std;


OvernightPackage::OvernightPackage(string sName, string sAdd, string sCity, string sState, unsigned int sZIP, string cName, string cAdd, string cCity, string cState, unsigned int cZIP, double Weight, double costPerWeight, double overnightFee)
	:Package(sName, sAdd, sCity, sState, sZIP, cName, cAdd, cCity, cState, cZIP, Weight, costPerWeight)
{
	feePerOunce = overnightFee;
}


OvernightPackage::~OvernightPackage()
{
}

double OvernightPackage::calculateCost()
{
	return Package::calculateCost() + (weight*feePerOunce);
}


void OvernightPackage::displayPackage(void) //Outputs to cout.
{
	cout << "This is an overnight package." << endl;
	cout << "The sender is ";
	displaySender();
	cout << "The recipient is ";
	displayCustomer();
	cout << "The package weighs " << weight << " ounces, and costs (at a rate of " << pricePerOunce << " per ounce plus an extra rate of " << feePerOunce << ") " << calculateCost() << " to ship.";
}
