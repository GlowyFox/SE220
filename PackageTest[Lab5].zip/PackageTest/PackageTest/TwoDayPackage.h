#pragma once
#include "Package.h"
class TwoDayPackage :
	Package
{
public:
	TwoDayPackage(std::string sName = "Doe", std::string sAdd = "Address", std::string sCity = "City", std::string sState = "State", unsigned int sZIP = 00000, std::string cName = "Doe", std::string cAdd = "Address", std::string cCity = "City", std::string cState = "State", unsigned int cZIP = 00000, double Weight = 0.0, double costPerWeight = 0.0, double speedyFee = 0.0);
	~TwoDayPackage();
	double calculateCost();
	void displayPackage(void);
private: 
	double fastFee;
};

