#pragma once
#include <string>
class Package
{
public:
	Package(std::string sName = "Doe", std::string sAdd = "Address", std::string sCity = "City", std::string sState = "State", unsigned int sZIP = 00000, std::string cName = "Doe", std::string cAdd = "Address", std::string cCity = "City", std::string cState = "State", unsigned int cZIP = 00000, double Weight = 0.0, double costPerWeight = 0.0); //Ouch. Just.. Ouch.
	~Package();
	double calculateCost();
	void setSender(std::string name, std::string add, std::string city, std::string state, unsigned int ZIP);
	void setCustomer(std::string name, std::string add, std::string city, std::string state, unsigned int ZIP);
	void setWeight(double newWeight);
	void setCostPerWeight(double newCostPerWeight);

	void displayPackage(void);
	void displaySender(void);
	void displayCustomer(void);
protected:
	std::string sendName;
	std::string sendAddress;
	std::string sendCity;
	std::string sendState;
	unsigned int sendZIPCode;

	std::string custName;
	std::string custAddress;
	std::string custCity;
	std::string custState;
	unsigned int custZIPCode;

	double weight;
	double pricePerOunce;
};

