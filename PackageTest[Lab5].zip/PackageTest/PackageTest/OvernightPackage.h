#pragma once
#include "Package.h"
class OvernightPackage :
	Package
{
public:
	OvernightPackage(std::string sName = "Doe", std::string sAdd = "Address", std::string sCity = "City", std::string sState = "State", unsigned int sZIP = 00000, std::string cName = "Doe", std::string cAdd = "Address", std::string cCity = "City", std::string cState = "State", unsigned int cZIP = 00000, double Weight = 0.0, double costPerWeight = 0.0, double overnightFee = 0.0);
	~OvernightPackage();
	double calculateCost();
	void displayPackage(void);
private:
	double feePerOunce;
};

