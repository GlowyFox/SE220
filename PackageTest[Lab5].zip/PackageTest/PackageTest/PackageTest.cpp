// PackageTest.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Package.h"
#include "TwoDayPackage.h"
#include "OvernightPackage.h"
#include <iostream>
#include <conio.h>

using namespace std;


int main()
{
	Package p1("John Doe", "123 North Columbia Way", "Jamestown", "Montana", 30304, "Jane Hopton", "3235 S 220th ST", "Springfield", "Illinois", 62711, 22.5, .35);
	cout << endl << "The first package is as follows: " << endl;
	p1.displayPackage();
	cout << endl;

	_getch(); 
	
	TwoDayPackage p2("Jayne Doe", "456 North Columbia Way", "Jamestown", "Montana", 30304, "Jane Hopton", "3235 S 220th ST", "Springfield", "Illinois", 62711, 22.5, .35, 2.50);
	cout << endl << "The second package is as follows: " << endl;
	p2.displayPackage();
	cout << endl;

	_getch();

	OvernightPackage p3("James Doe", "534 North Columbia Way", "Jamestown", "Montana", 30304, "Jane Hopton", "3235 S 220th ST", "Springfield", "Illinois", 62711, 22.5, .35, 0.6);
	cout << endl << "The third package is as follows: " << endl;
	p3.displayPackage();
	cout << endl;

	_getch();

    return 0;
}

