#include "stdafx.h"
#include "TwoDayPackage.h"
#include <iostream>

using namespace std;


TwoDayPackage::TwoDayPackage(string sName, string sAdd, string sCity, string sState, unsigned int sZIP, string cName, string cAdd, string cCity, string cState, unsigned int cZIP, double Weight, double costPerWeight, double speedyFee)
	:Package(sName, sAdd, sCity, sState, sZIP, cName, cAdd, cCity, cState, cZIP, Weight, costPerWeight)
{
	fastFee = speedyFee;
}


TwoDayPackage::~TwoDayPackage()
{
}

double TwoDayPackage::calculateCost()
{
	return Package::calculateCost() + fastFee;
}

void TwoDayPackage::displayPackage(void) //Outputs to cout.
{
	cout << "This is a two-day package." << endl;
	cout << "The sender is ";
	displaySender();
	cout << "The recipient is ";
	displayCustomer();
	cout << "The package weighs " << weight << " ounces, and costs (at a rate of " << pricePerOunce << " per ounce plus a flat fee of " << fastFee << ") " << calculateCost() << " to ship.";
}