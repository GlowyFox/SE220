#include "stdafx.h"
#include "Package.h"
#include <iostream>

using namespace std;


Package::Package(string sName, string sAdd, string sCity, string sState, unsigned int sZIP, string cName, string cAdd, string cCity, string cState, unsigned int cZIP, double Weight, double costPerWeight)
{
	setSender(sName, sAdd, sCity, sState, sZIP); 
	setCustomer(cName, cAdd, cCity, cState, cZIP);
	setWeight(Weight);
	setCostPerWeight(costPerWeight);
}

Package::~Package()
{
}

double Package::calculateCost()
{
	return (pricePerOunce * weight);
}

void Package::setSender(string name, string add, string city, string state, unsigned int ZIP)
{
	sendName = name; 
	sendAddress = add;
	sendCity = city;
	sendState = state;
	sendZIPCode = ZIP;
}

void Package::setCustomer(string name, string add, string city, string state, unsigned int ZIP)
{
	custName = name;
	custAddress = add;
	custCity = city;
	custState = state;
	custZIPCode = ZIP;
}

void Package::setWeight(double newWeight)
{
	weight = newWeight;
}

void Package::setCostPerWeight(double newCostPerWeight)
{
	pricePerOunce = newCostPerWeight;
}

void Package::displayPackage(void) //Outputs to cout.
{
	cout << "This is a standard package." << endl;
	cout << "The sender is ";
	displaySender();
	cout << "The recipient is ";
	displayCustomer();
	cout << "The package weighs " << weight << " ounces, and costs (at a rate of " << pricePerOunce << " per ounce) " << calculateCost() << " to ship.";
}

void Package::displaySender(void) //Outputs to cout.
{
	cout << sendName << " at " << sendAddress << ", " << sendCity << ", " << sendState << ", " << sendZIPCode << endl;
}

void Package::displayCustomer(void) //Outputs to.. You get the idea.
{
	cout << custName << " at " << custAddress << ", " << custCity << ", " << custState << ", " << custZIPCode << endl;
}
