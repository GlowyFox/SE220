// MiniArena.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Creature.h"
#include <ctime>
#include <random>
#include <iostream>
#include <iomanip>
#include <conio.h>
#include <string>

using namespace std;

int _tmain(int argc, _TCHAR* argv[])
{
	//Seeding the RNG.
	srand(time(0));

	//Loop Control Variable
	bool FightIsGoing = true;
	bool hasAttacked = false;
	//The creatures!
	Creature Creature1, Creature2;
	Creature* ActiveCreature;
	Creature* TargetCreature; //Will be randomized when not one-on-one.
	//Tells which creature is active.
	int NextActiveCreature = (rand()%2);
	int numCreatures = 2;
	//Round counter
	int roundCounter = 0;

	//MORTAL KOMBAAAT (cue music)
	do
	{
		roundCounter++;
		//Switch for future expansion. Controls who is going.
		switch(NextActiveCreature){
		case 0:
			ActiveCreature = &Creature1;
			TargetCreature = &Creature2;
			break;
		case 1:
			ActiveCreature = &Creature2;
			TargetCreature = &Creature1;
			break;
		default:
			throw exception();
		}

		//Creature turn cycling!
		NextActiveCreature++;
		if(NextActiveCreature == numCreatures)
		{
			NextActiveCreature = 0;
		}

		cout << ActiveCreature->TakeTurn(&hasAttacked) << endl;
		if(hasAttacked)
		{
			cout << ActiveCreature->AttackTarget(TargetCreature) << endl;
		}

		if(TargetCreature->getHealth() == 0) //Only checking the targeted creature, as they are the one that took damage.
		{
			FightIsGoing = false;
		}

		if(NextActiveCreature == 0)
		{
			//Output the current creature statuses.
			cout << "End of turn cycle." << endl << "Statuses"<< endl << Creature1 << endl << Creature2 << endl;
			_getch();
		}

		
	}while(FightIsGoing);

	cout << endl << ActiveCreature->getName() + " is the victor!" << endl;
	cout << "Final Statuses"<< endl << Creature1 << endl << Creature2 << endl << endl;
		
	_getch();

	return 0;
}

