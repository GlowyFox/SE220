#pragma once
#include <string>
#include <random>
#include <iostream>
#include "stdafx.h"
class Creature
{
	
protected:	
	static const std::string NameList[];
	static const std::string TitleList[];
private:
	std::string FullName;
	int Health;
	int MaxHealth;
	int Attack;
	int Defense;
	int Regen;
	bool isDodging;
	bool isHealing;
public:
	Creature(void);
	~Creature(void);
	std::string TakeDamage(int damageIn);
	std::string TakeTurn(bool* Attacked);
	std::string ReadyDodge(void);
	std::string Heal(void);
	std::string AttackTarget(Creature* Defender);
	int getHealth(void);
	void setHealth(int inHealth);
	int getAttack(void);
	void setAttack(int inAttack);
	int getDefense(void);
	void setDefense(int inDefense);
	int getRegen(void);
	void setRegen(int inRegen);
	bool getDodgeStatus(void);
	void setDodgeStatus(bool inDodge);
	bool getRegenStatus(void);
	void setRegenStatus(bool inRegen);
	std::string getName(void);
	void setName(std::string newName);

	
	friend std::ostream& operator<< (std::ostream& stream, const Creature& displayCreature);
};

