#include "stdafx.h"
#include "Creature.h"

//Defining the list of Names and Titles (FirstName, LastName essentially - Since when did a combat creatures get last names?)

const std::string Creature::NameList[] = {"Jack","James","Bob", "Oogie", "Fluffy"};
const std::string Creature::TitleList[] = {"Unstoppable","Terrible","Incredible", "Nightmare", "Immortal"};

Creature::Creature(void)
{
	//10-30
	setHealth((rand() % 21) + 10);
	MaxHealth = getHealth();
	//10-20
	setAttack((rand() % 11) + 10);
	//10-20
	setDefense((rand() % 11) + 10);
	//5-15
	setRegen((rand() % 11) + 5);
	//Not dodging
	setDodgeStatus(false);
	//Not healing
	setRegenStatus(false);

	std::string MyName = NameList[rand() % 5]; //MAKE SURE TO CHANGE THE NUMBER WHEN THE ARRAY SIZE CHANGES!
	MyName += " the " + TitleList[rand() % 5]; //MAKE SURE TO CHANGE THE NUMBER WHEN THE ARRAY SIZE CHANGES!
	setName(MyName);
}


Creature::~Creature(void)
{
}

//Tells this creature to try attacking the given target. TODO: Make damage dependant on a stat + a die roll. Also, missable attacks without dodging.
std::string Creature::AttackTarget(Creature* Defender)
{
	return Defender->TakeDamage(getAttack() + (rand()%10)) + getName() + "'s attack!";
}

//Tells this creature to deal with the given damage. TODO: Die rolling with defense.
std::string Creature::TakeDamage(int damageIn)
{
	damageIn -= getDefense() + (rand()%10);
	if(getDodgeStatus())
	{
		setDodgeStatus(false);
		return getName() + " dodged ";
	}
	else if(damageIn <= 0)
	{
		return getName() + " blocked ";
	}
	else if(damageIn < getHealth())
	{		
		setHealth(getHealth()-damageIn);
		return getName() + " was hurt by ";
	}
	else
	{
		setHealth(0);
		return getName() + " falls to ";
	}
}

//Tells this creature to get ready to dodge the next attack against it. TODO: Doubles defense instead, to make the attack roll harder.
std::string Creature::ReadyDodge(void)
{
	setDodgeStatus(true);
	return getName() + " gets ready to dodge!";
}

//Tells the creature to heal itself.
std::string Creature::Heal(void)
{	
	int newHealth = getHealth()+getRegen();
	if(newHealth > MaxHealth)
	{
		newHealth = MaxHealth;
	}
	setHealth(newHealth);
	return getName() + " heals themselves!";
}

//Tells the creature to decide the action for its turn.
std::string Creature::TakeTurn(bool* Attacked)
{
	int action = (rand()%100)+1;

	
	setRegenStatus(false);

	//Chances: 10% - Dodge
	//         20% - Heal
	//   Remainder - Attack

	if(action > 50 && action <= 60 && !getDodgeStatus()) //Dodging
	{
		*Attacked = false;
		return ReadyDodge();
	}
	else if(action <= 50 && action > 30 && !getRegenStatus() && getHealth() != MaxHealth) //Healing
	{
		*Attacked = false;
		setRegenStatus(true); //This suddenly seems superfluous with my implementation..
		return Heal();
	}
	else
	{
		*Attacked = true;
		return getName() + " gets ready to attack!";
	}

}

//Output overload.
std::ostream& operator <<(std::ostream& stream, const Creature& displayCreature)
{
	stream << "          Name: " << displayCreature.FullName << std::endl;
	stream << "Maximum Health: " << displayCreature.MaxHealth << std::endl;
	stream << "Current Health: " << displayCreature.Health << std::endl;
	stream << "  Attack Power: " << displayCreature.Attack << std::endl;
	stream << "       Defense: " << displayCreature.Defense << std::endl;
	stream << " Regen Ability: " << displayCreature.Regen << std::endl;
	stream << "       Dodging? " << (displayCreature.isDodging?"Yes":"No") << std::endl;
	stream << "   Just healed? " << (displayCreature.isHealing?"Yes":"No") << std::endl;

	return stream;
}

//And now, the getter/setter pairs. No, I will not comment each one, that'd take waay too long.
int Creature::getHealth(void)
{
	return Health;
}
void Creature::setHealth(int inHealth)
{
	Health = inHealth;
}
int Creature::getAttack(void)
{
	return Attack;
}
void Creature::setAttack(int inAttack)
{
	Attack = inAttack;
}
int Creature::getDefense(void)
{
	return Defense;
}
void Creature::setDefense(int inDefense)
{
	Defense = inDefense;
}
int Creature::getRegen(void)
{
	return Regen;
}
void Creature::setRegen(int inRegen)
{
	Regen = inRegen;
}
bool Creature::getDodgeStatus(void)
{
	return isDodging;
}
void Creature::setDodgeStatus(bool inDodge)
{
	isDodging = inDodge;
}
bool Creature::getRegenStatus(void)
{
	return isHealing;
}
void Creature::setRegenStatus(bool inRegen)
{
	isHealing = inRegen;
}
std::string Creature::getName(void)
{
	return FullName;
}
void Creature::setName(std::string newName)	
{
	FullName = newName;
}
